import React from "react";
import { useState, useEffect } from "react";
import "../App.css";
import Rules from "./Rules";
import PriceRange from "./PriceRange";
import Simulation from "./Simulation.jsx";

export default function Trading({
    mode,
    setMode,
    manualTrade,
    setManualTrade,
    autoTrade,
    setAutoTrade,
}) {
    // console.log("Manual!!!: ", manualTrade);
    
    const switchMode = (next) => setMode && setMode(next);

    // useEffect(() => {
    //     console.log("///");
    //     setManualTrade({ isEnabled: false, rules: rules });
    //     setAutoTrade({ isEnabled: false, minPrice: minPrice, maxPrice: maxPrice, time: time });
    // }, [rules, minPrice, maxPrice, time]);

    // console.log("RULES: ", rules);
    // console.log("******", autoTrade);

    return (
        <div className="tabs-wrap fancy-card">
            <div className="tabs">
                <button
                    type="button"
                    className={`tab ${mode === "Trading" ? "active" : ""}`}
                    onClick={() => switchMode("Trading")}
                    aria-pressed={mode === "Trading"}
                >
                    Trading
                </button>
                <button
                    type="button"
                    className={`tab ${mode === "Simulation" ? "active" : ""}`}
                    onClick={() => switchMode("Simulation")}
                    aria-pressed={mode === "Simulation"}
                >
                    Simulation
                </button>
            </div>

            <div className="tab-content">
                {mode === "Trading" ? (
                    <>
                        <div className="rules-scroll">
                            <Rules manualTrade={manualTrade} setManualTrade={setManualTrade} />
                        </div>
                        <PriceRange autoTrade={autoTrade} setAutoTrade={setAutoTrade} />
                    </>
                ) : null}
            </div>
        </div>
    );
}
