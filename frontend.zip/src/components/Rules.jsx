import React from 'react';
import { useState, useEffect } from 'react';
import "../App.css";

function Rules({ manualTrade, setManualTrade }) {
  const [forms, setForms] = useState(manualTrade.rules || []);

  useEffect(() => {
    setManualTrade({isEnabled: manualTrade.isEnabled, rules: manualTrade.rules});
  }, [manualTrade]);

  const addRule = () => {
    const newRule = {
      id: (forms.at(-1)?.id ?? 0) + 1,
      setpoint: null,
      side: false,
      percentage: 100
    };
    setForms([...forms, newRule]);
    setManualTrade(prev => ({...prev, rules: forms}));
  };

  const deleteRule = (id) => {
    setForms(forms.filter(rule => rule.id !== id));
  };

  const handleChange = (id, field, value) => {
    setForms(forms.map(rule => {
      if (rule.id !== id) return rule;
      let v = value;
      if (field === 'side') v = (value === true || value === 'true' || value === 1 || value === '1');
      if (field === 'setpoint' || field === 'percentage') v = Number(value) || 0;
      return { ...rule, [field]: v };
    }));
  };

  return (
    <>
      <div className="rules-wrap">
        {/* Only this list becomes scrollable */}
        <div className="rules-scroll" role="region" aria-label="Trading rules">
          {forms.map((r) => (
            <div className="swap-form fancy-card" id={`rule-${r.id}`} key={r.id}>
              <button
                className="delete-button pretty"
                onClick={() => deleteRule(r.id)}
                aria-label={`Delete rule ${r.id}`}
                title="Delete"
              >
                ×
              </button>

              <div className="form-row">
                <div className="form-group">
                  <label>Set Point</label>
                  <input
                    type="number"
                    step="any"
                    className="form-input"
                    placeholder="e.g. 175.20"
                    onChange={(e) => handleChange(r.id, 'setpoint', parseFloat(e.target.value))}
                    value={r.setpoint ?? ""}
                  />
                </div>

                <div className="form-group">
                  <label>Direction</label>
                  <select
                    className="form-input"
                    value={r.side ? 'true' : 'false'}
                    onChange={(e) => handleChange(r.id, 'side', e.target.value === 'true')}
                  >
                    <option value="true">USDT → SOL</option>
                    <option value="false">SOL → USDT</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Percentage</label>
                  <input
                    type="number"
                    step="any"
                    className="form-input"
                    value={r.percentage ?? ""}
                    placeholder="e.g. 10"
                    onChange={(e) => handleChange(r.id, 'percentage', parseFloat(e.target.value))}
                  />
                </div>
              </div>
            </div>
          ))}

          {forms.length === 0 && (
            <div className="empty-state" style={{ marginTop: 8 }}>
              No rules yet. Click “Add Rule” to create one.
            </div>
          )}
        </div>

        <div className="panel-actions">
          <button className="add-button gradient" onClick={addRule}>
            + Add Rule
          </button>
        </div>
      </div>
    </>
  );
}

export default Rules;
