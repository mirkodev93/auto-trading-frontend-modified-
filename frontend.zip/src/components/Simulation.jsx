import React from 'react';

const Simulation = () => {
    return (
        <></>
    );
};

export default Simulation;